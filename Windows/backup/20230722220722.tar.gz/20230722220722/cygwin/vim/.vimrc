set cul
set nu
set mouse=a
set clipboard+=unnamed
set hlsearch
set incsearch
set showmatch
set cursorline
set ignorecase
set visualbell
set noerrorbells
set softtabstop=4
set shiftwidth=4
set ts=4
set expandtab
set autoindent
set t_Co=256
set hlsearch
set incsearch
syntax on
filetype indent on

set fileencodings=utf-8,ucs-bom,gb18030,gbk,gb2312,cp936
set termencoding=utf-8
set encoding=utf-8
