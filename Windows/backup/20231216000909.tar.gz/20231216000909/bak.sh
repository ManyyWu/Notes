#!/bin/bash

cd ~/backup
DIR=$(date +%+4Y%m%d%H%M%S)
mkdir "$DIR"
if [[ $? != '0' ]]; then
	echo Duplicate backup: $DIR
	exit 1
fi


# bash
mkdir -p "$DIR/cygwin/bash/" || exit 1
cp -fv ~/.bashrc "$DIR/cygwin/bash/" || exit 1


# vim
mkdir -p "$DIR/cygwin/vim/" || exit 1
cp -fv ~/.vimrc "$DIR/cygwin/vim/" || exit 1


# clion
mkdir -p "$DIR/clion/ideavim/" || exit 1
cp -fv "$W_HOME/.ideavimrc" "$DIR/clion/ideavim/" || exit 1

mkdir -p "$DIR/clion/keymaps/" || exit 1
cp -fv "$W_HOME/appdata/roaming/jetbrains/clion2023.1/keymaps/mykeymaps.xml" "$DIR/clion/keymaps/" || exit 1

mkdir -p "$DIR/clion/settings/" || exit 1
cp -fv "$W_HOME/appdata/roaming/jetbrains/clion2023.1/settings.zip" "$DIR/clion/settings/" || exit 1


# windows terminal Preview
mkdir -p "$DIR/terminal/" || exit 1
TERMINAL_DIR="$W_HOME/AppData/Local/Packages/Microsoft.WindowsTerminal*/LocalState"
if [[ $(find $TERMINAL_DIR) != '' ]]; then
	TERMINAL_DIR=$(find $TERMINAL_DIR | head -n 1)
	if [[ -d $TERMINAL_DIR ]]; then
		cp -fv "$TERMINAL_DIR/settings.json" "$DIR/terminal/" || exit 1
		cp -fv "$TERMINAL_DIR/state.json" "$DIR/terminal/" || exit 1
	fi
else
	exit 1
fi


# clash
mkdir -p "$DIR/clash/" || exit 1
cp -fv "$W_HOME/.config/clash/cfw-settings.yaml" "$DIR/clash/"
cp -fv "$W_HOME/.config/clash/config.yaml" "$DIR/clash/"


# pack
cp bak.sh "$DIR"
tar czf "$DIR.tar.gz" "$DIR" || exit 1
rm -Rf "$DIR"

echo "done!"
